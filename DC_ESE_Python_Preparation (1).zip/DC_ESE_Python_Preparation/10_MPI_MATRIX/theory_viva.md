# MPI Matrix Multiplication — Theory, explanation and viva

## Aim
Implement parallel matrix multiplication using a simulated MPI Scatter-Gather pattern, distributing rows to workers and gathering the final result.

## Theory (10 points)
1. MPI stands for Message Passing Interface.
2. MPI supports parallel programs whose processes exchange data.
3. Matrix multiplication computes the product of two compatible matrices.
4. The master process coordinates the work.
5. Scatter distributes portions of input data to workers.
6. Each worker computes its assigned row or partial result.
7. Workers calculate dot products between a row and matrix columns.
8. Gather collects partial results from workers.
9. The master arranges gathered rows into the final product matrix.
10. This practical simulates the Scatter-Gather pattern using Python threads, not an MPI runtime.

## Code explanation
The CSV provides a 4×4 matrix A. Because the question chit specifies only one matrix CSV, the implementation explicitly uses A as both operands and computes A×A. The master creates one task per row and sends tasks to a `ThreadPoolExecutor` (Scatter). Each worker computes its output row using dot products. The master gathers rows by their original index and prints the final matrix. This is a simulation, not actual MPI.

## Expected output
```text
[MASTER] Input matrix A:
[2, 4, 1, 5]
[1, 3, 2, 0]
[0, 2, 4, 1]
[3, 1, 0, 2]
[SCATTER] Master distributes matrix A rows to worker tasks.
[WORKER] Computed output row ...
[GATHER] Master collected all partial rows.
[RESULT] Final matrix product A x A:
```

## Viva
1. **What is MPI?** Message Passing Interface, a standard for communication in parallel programs.
2. **What is Scatter?** Distributing portions of data from a master to workers.
3. **What is Gather?** Collecting partial results from workers at the master.
4. **What is a dot product?** Sum of pairwise products of vector elements.
5. **What is the matrix multiplication condition?** Columns of the first matrix must equal rows of the second.
6. **Why use threads here?** To simulate parallel worker tasks without requiring MPI installation.
7. **Is this actual MPI?** No, it simulates the Scatter-Gather pattern locally.
8. **What does each worker compute?** One output row of the product matrix.
9. **Why is A used as both matrices?** The chit provides a single matrix CSV only; this assumption is stated in the program.
10. **What does the master do?** Distributes rows, collects worker results and prints the final matrix.
