"""
SIMULATED MPI SCATTER-GATHER MATRIX MULTIPLICATION
CSV columns: row_id,col_0,col_1,col_2,col_3
The CSV supplies matrix A. For a self-contained question dataset, this program
uses A as both operands and computes A x A. Rows are distributed to worker
threads (Scatter), then partial rows are collected (Gather).
Run: python main.py [csv_filename]
"""
import csv
import sys
from concurrent.futures import ThreadPoolExecutor

def multiply_row(args):
    row_index, row, matrix_b = args
    result = []
    for col in range(len(matrix_b[0])):
        value = sum(row[k] * matrix_b[k][col] for k in range(len(row)))
        result.append(value)
    print(f"[WORKER] Computed output row {row_index}: {result}")
    return row_index, result

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "matrix_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            records = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    if not records:
        print("[ERROR] Matrix CSV is empty.")
        return

    columns = ["col_0", "col_1", "col_2", "col_3"]
    try:
        matrix_a = [[int(r[c]) for c in columns] for r in records]
    except (KeyError, ValueError):
        print("[ERROR] Expected numeric columns col_0 through col_3.")
        return

    if len(matrix_a) != 4:
        print("[ERROR] This sample implementation expects exactly 4 matrix rows.")
        return

    matrix_b = matrix_a  # The chit supplies one matrix dataset; multiply A by A.
    print("=== SIMULATED MPI SCATTER-GATHER ===")
    print("[MASTER] Input matrix A:")
    for row in matrix_a:
        print(row)
    print("[MASTER] Matrix B is set to A because the chit supplies one matrix CSV.")
    print("[SCATTER] Master distributes matrix A rows to worker tasks.")

    tasks = [(i, matrix_a[i], matrix_b) for i in range(len(matrix_a))]
    gathered = [None] * len(matrix_a)
    with ThreadPoolExecutor(max_workers=4) as executor:
        for row_index, result_row in executor.map(multiply_row, tasks):
            gathered[row_index] = result_row

    print("[GATHER] Master collected all partial rows.")
    print("[RESULT] Final matrix product A x A:")
    for row in gathered:
        print(row)

if __name__ == "__main__":
    main()
