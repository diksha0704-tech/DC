"""
MULTITHREADED TASK PROCESSING WITH MUTEX
CSV columns: task_id,thread_name,burst_ms,priority,status
Run: python main.py [csv_filename]
"""
import csv
import sys
import threading
import time

completed_tasks = []
completed_lock = threading.Lock()

def worker(task):
    task_id = task["task_id"]
    thread_name = task["thread_name"]
    burst = int(task["burst_ms"])
    print(f"[START] {thread_name} started {task_id} (priority={task['priority']})")
    # Simulate task work outside the critical section.
    time.sleep(max(0, burst) / 1000.0)

    print(f"[LOCK] {thread_name} waiting for mutex")
    with completed_lock:
        print(f"[LOCK] {thread_name} acquired mutex")
        completed_tasks.append(task_id)
        print(f"[UPDATE] {task_id} marked COMPLETED")
        print(f"[UNLOCK] {thread_name} released mutex")
    print(f"[DONE] {thread_name} finished {task_id}")

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "tasks_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            tasks = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    print("=== CONCURRENT TASK PROCESSING ===")
    threads = []
    for task in tasks:
        if task["status"].strip().upper() == "PENDING":
            t = threading.Thread(target=worker, args=(task,))
            threads.append(t)
            t.start()

    for t in threads:
        t.join()

    print("\n=== FINAL COMPLETED TASK LIST ===")
    for task_id in completed_tasks:
        print(f"{task_id}: COMPLETED")
    print(f"[SUMMARY] Completed {len(completed_tasks)} task(s).")

if __name__ == "__main__":
    main()
