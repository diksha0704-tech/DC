# Multithreading and Mutex — Theory, explanation and viva

## Aim
Implement a multithreaded worker simulation using thread locks (Mutex) to safely process CSV tasks without race conditions.

## Theory (10 points)
1. A thread is a lightweight unit of execution within a process.
2. Multithreading allows multiple threads to make progress concurrently.
3. Each worker thread processes a task from the CSV file.
4. Shared data may be accessed by multiple threads.
5. A race condition occurs when concurrent access causes an unpredictable result.
6. A critical section is code that accesses shared resources.
7. A mutex lock allows only one thread at a time into the protected section.
8. A thread acquires the lock before updating shared data.
9. It releases the lock after the update.
10. `join()` makes the main thread wait until workers finish.

## Code explanation
Each CSV row creates a worker thread. The thread simulates work using `sleep()` outside the critical section. It then acquires `completed_lock`, appends its task ID to the shared list, and releases the lock. `join()` waits for every worker before printing the final list. Thread print order can vary.

## Expected output (illustrative)
```text
=== CONCURRENT TASK PROCESSING ===
[START] Worker_1 started T1 (priority=HIGH)
[START] Worker_2 started T2 (priority=MEDIUM)
[LOCK] Worker_2 acquired mutex
[UPDATE] T2 marked COMPLETED
[UNLOCK] Worker_2 released mutex
...
[SUMMARY] Completed 4 task(s).
```

## Viva
1. **What is a thread?** A lightweight execution path within a process.
2. **What is multithreading?** Running multiple threads concurrently in one process.
3. **What is a race condition?** A result that depends on unpredictable thread timing.
4. **What is a mutex?** A mutual-exclusion lock that protects a critical section.
5. **What is a critical section?** Code that accesses shared data.
6. **Why is the lock used here?** To protect updates to the shared completed-task list.
7. **What does `start()` do?** Starts a thread's execution.
8. **What does `join()` do?** Waits for a thread to finish.
9. **Why is sleep outside the lock?** So workers can perform simulated work concurrently.
10. **Is thread execution order guaranteed?** No, scheduling order can vary.
