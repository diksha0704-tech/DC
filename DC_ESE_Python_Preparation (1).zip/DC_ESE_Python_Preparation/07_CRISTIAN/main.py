"""
CRISTIAN'S CLOCK SYNCHRONIZATION
CSV columns: client_id,t0_send_ms,t_server_ms,t1_recv_ms
Run: python main.py [csv_filename]
"""
import csv
import sys

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "cristian_clocks_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    print("=== CRISTIAN'S CLOCK SYNCHRONIZATION ===")
    for r in rows:
        client = r["client_id"]
        t0 = float(r["t0_send_ms"])
        ts = float(r["t_server_ms"])
        t1 = float(r["t1_recv_ms"])
        rtt = t1 - t0
        estimated = ts + (rtt / 2)
        offset = estimated - t1
        adjusted = t1 + offset
        print(f"\n[CLIENT] {client}")
        print(f"RTT = T1 - T0 = {t1:g} - {t0:g} = {rtt:g} ms")
        print(f"Estimated server time = T_server + RTT/2 = {ts:g} + {rtt/2:g} = {estimated:g} ms")
        print(f"Local clock offset adjustment = {offset:g} ms")
        print(f"Adjusted client time = {adjusted:g} ms")

if __name__ == "__main__":
    main()
