# Cristian's Algorithm — Theory, explanation and viva

## Aim
Calculate round-trip time (RTT), estimated server time and the client's clock adjustment from CSV records.

## Theory (10 points)
1. Cristian's algorithm synchronizes a client clock with a time server.
2. The client sends a request at local time T0.
3. The server replies with its current time, T_server.
4. The client receives the reply at local time T1.
5. Round-trip time is calculated as `RTT = T1 - T0`.
6. The algorithm estimates one-way network delay as RTT/2.
7. Estimated server time at client receipt is `T_server + RTT/2`.
8. The client compares this estimate with its local receive time.
9. Offset is `estimated_server_time - T1`.
10. The client adjusts its clock by the calculated offset.

## Code explanation
For each CSV row, the program calculates RTT, adds half the RTT to the server timestamp, and compares the estimate with the client's receive time. It prints the offset and adjusted time. The implementation follows the exact formula specified in the question chit.

## Expected output
For C1 (T0=1000, server=1050, T1=1100):
```text
RTT = 1100 - 1000 = 100 ms
Estimated server time = 1050 + 50 = 1100 ms
Local clock offset adjustment = 0 ms
Adjusted client time = 1100 ms
```

## Viva
1. **What is Cristian's algorithm?** A client-server clock synchronization algorithm.
2. **What is T0?** Client request-send time.
3. **What is T1?** Client reply-receive time.
4. **What is RTT?** Time from sending a request to receiving its reply.
5. **Why divide RTT by two?** To estimate one-way delay, assuming roughly symmetric delay.
6. **What is T_server?** Timestamp returned by the time server.
7. **How is estimated server time calculated?** `T_server + RTT/2`.
8. **What is clock offset?** Difference between estimated server time and client local time.
9. **What assumption is made?** Network delay is approximately symmetric.
10. **One limitation?** Variable or asymmetric network delay reduces accuracy.
