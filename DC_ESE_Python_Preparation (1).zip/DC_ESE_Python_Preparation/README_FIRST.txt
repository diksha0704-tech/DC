DISTRIBUTED COMPUTING LAB ESE — PYTHON PREPARATION
=================================================

This repository contains 10 self-contained Python implementations based on the
question-chit patterns in the uploaded DC SAMPLE LAB MANUAL.pdf.

FOLDERS
-------
01_RMI_RPC
02_BULLY
03_RING
04_MULTITHREADING
05_LAMPORT_CLOCK
06_VECTOR_CLOCK
07_CRISTIAN
08_BERKELEY
09_LOAD_BALANCING
10_MPI_MATRIX

REQUIREMENTS
------------
- Python 3
- No third-party Python packages required.
- All programs use Python standard-library modules only.
- Run in the VS Code terminal.

HOW TO RUN
----------
1. Open the relevant experiment folder in VS Code.
2. Put the assigned CSV file in the same folder as main.py.
3. Open the VS Code terminal in that folder.
4. Run:
       python main.py assigned_file.csv
   Example:
       python main.py tasks_4.csv
5. If no filename is supplied, the program uses its included sample CSV:
       python main.py

IMPORTANT CSV NAME RULE
-----------------------
The question chits use numbered filenames such as tasks_4.csv, tasks_88.csv,
events_29.csv, node_clocks_3.csv, matrix_22.csv, etc. The program accepts the
filename as a command-line argument, so you do NOT need to edit the code.
Use the exact filename and exact column headers printed on your assigned chit.

TOPIC-TO-CSV HEADERS
--------------------
RMI/RPC:
call_id,client_name,method_name,param_value,timestamp

Bully:
node_id,is_alive,is_current_coordinator

Ring:
node_id,next_node_id,is_active,priority_rank

Multithreading:
task_id,thread_name,burst_ms,priority,status

Lamport:
event_id,process_id,event_type,message_to,initial_clock

Vector:
event_id,process_id,event_action,target_process

Cristian:
client_id,t0_send_ms,t_server_ms,t1_recv_ms

Berkeley:
node_id,clock_time_sec,is_faulty

Load balancing:
job_id,compute_units,assigned_worker,status

MPI matrix:
row_id,col_0,col_1,col_2,col_3

NOTES / ASSUMPTIONS THAT MATTER
-------------------------------
1. RPC/RMI is a local dispatcher simulation, not a real network connection.
2. Bully chooses the highest-ID active node.
3. Ring follows next_node_id, skips inactive nodes and elects the highest ID
   included in the election token.
4. Multithreading protects the shared completed-task list with a mutex.
5. Lamport RECEIVE rows use message_to to identify the sender; SEND rows use
   message_to to identify the receiver. Events are processed in CSV order.
6. Vector RECEIVE rows use target_process to identify the sender; SEND rows
   use target_process to identify the receiver. Supported process IDs: P1-P3.
7. Cristian uses the exact formula in the chit:
   RTT = T1 - T0; estimated server time = T_server + RTT/2.
8. Berkeley excludes rows explicitly marked is_faulty=TRUE. The chit does not
   define a numerical outlier threshold.
9. Load balancing runs both Round Robin and Least Connections for comparison.
10. MPI question supplies only one matrix CSV. This implementation explicitly
    computes A x A using Python worker threads to simulate Scatter-Gather.
    It is not actual MPI.

BEFORE THE EXAM
---------------
- Test every folder once.
- Check that Python runs using: python --version
- Keep a backup copy of this folder.
- Follow the exact instructions and permitted-resource rules given by faculty.
- Understand the program; do not rely only on memorizing it.
