# Bully Algorithm — Theory, explanation and viva

## Aim
Implement the Bully Leader Election Algorithm where a node detects coordinator failure and the highest-ID active node becomes coordinator.

## Theory (10 points)
1. Bully is a distributed leader-election algorithm.
2. Every process has a unique numeric ID.
3. The process with the highest active ID is preferred as coordinator.
4. A process detects failure when the coordinator does not respond.
5. The detecting process sends ELECTION messages to processes with higher IDs.
6. Higher active processes respond with OK.
7. A higher process can start its own election.
8. Eventually the highest active process wins.
9. The winner broadcasts a COORDINATOR message.
10. All active processes update their coordinator information.

## Code explanation
The program reads node IDs and status flags from CSV. It checks whether the old coordinator is alive. If not, an active node initiates an election, sends ELECTION messages to higher active IDs, receives simulated OK responses, and the highest active ID broadcasts COORDINATOR.

## Expected output (illustrative)
```text
[FAILURE] Coordinator failure detected.
[ELECTION] Node 1 initiates election.
[ELECTION] Node 1 sends ELECTION to Node 2
[OK] Node 2 responds OK
...
[RESULT] New coordinator is Node 5
```

## Viva
1. **What is leader election?** Choosing one process to coordinate a distributed system.
2. **Why is it called Bully?** A higher-ID process can take over the election from a lower-ID process.
3. **Which node wins?** The highest-ID active process.
4. **What is an ELECTION message?** A request asking higher-ID processes to participate.
5. **What does OK mean?** A higher process is alive and will continue the election.
6. **What is COORDINATOR message?** The winner announces its leadership.
7. **What if no higher node responds?** The initiator can become coordinator.
8. **What if the highest-ID node fails?** The next-highest active node can win.
9. **What information is in the CSV?** Node ID, alive status and coordinator status.
10. **One limitation?** It can generate many messages, especially in large systems.
