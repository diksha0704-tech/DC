"""
BULLY LEADER ELECTION
CSV columns: node_id,is_alive,is_current_coordinator
Run: python main.py [csv_filename]
"""
import csv
import sys

def truth(value):
    return value.strip().lower() in ("true", "1", "yes", "alive")

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "bully_cluster_sample.csv"
    nodes = []
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                nodes.append({
                    "id": int(r["node_id"]),
                    "alive": truth(r["is_alive"]),
                    "coordinator": truth(r["is_current_coordinator"])
                })
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    nodes.sort(key=lambda n: n["id"])
    alive = [n for n in nodes if n["alive"]]
    if not alive:
        print("[ELECTION] No active nodes. Leader cannot be elected.")
        return

    old = next((n for n in nodes if n["coordinator"]), None)
    if old and old["alive"]:
        print(f"[STATUS] Current coordinator Node {old['id']} is alive.")
        return

    print("[FAILURE] Coordinator failure detected.")
    highest = max(n["id"] for n in alive)
    initiator = next((n for n in alive if n["id"] < highest), alive[-1])
    print(f"[ELECTION] Node {initiator['id']} initiates election.")

    higher = [n for n in alive if n["id"] > initiator["id"]]
    if not higher:
        print(f"[COORDINATOR] Node {initiator['id']} is the highest active node.")
        return

    for n in higher:
        print(f"[ELECTION] Node {initiator['id']} sends ELECTION to Node {n['id']}")
        print(f"[OK] Node {n['id']} responds OK")

    leader = max(alive, key=lambda n: n["id"])
    print(f"[ELECTION] Node {leader['id']} wins because it has the highest active ID.")
    for n in alive:
        if n["id"] != leader["id"]:
            print(f"[COORDINATOR] Node {leader['id']} broadcasts COORDINATOR to Node {n['id']}")
    print(f"[RESULT] New coordinator is Node {leader['id']}")

if __name__ == "__main__":
    main()
