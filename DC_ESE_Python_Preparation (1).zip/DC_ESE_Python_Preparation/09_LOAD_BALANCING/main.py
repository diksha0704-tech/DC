"""
DYNAMIC LOAD BALANCING
CSV columns: job_id,compute_units,assigned_worker,status
Runs both Round Robin and Least Connections for comparison.
Run: python main.py [csv_filename]
"""
import csv
import sys

WORKERS = ["Worker_1", "Worker_2", "Worker_3"]

def schedule(jobs, strategy):
    counts = {w: 0 for w in WORKERS}
    loads = {w: 0 for w in WORKERS}
    results = []
    rr_index = 0

    print(f"\n=== {strategy.upper()} SCHEDULING ===")
    for job in jobs:
        if job["status"].strip().upper() != "PENDING":
            continue
        if job["assigned_worker"].strip().upper() not in ("", "UNASSIGNED"):
            continue

        if strategy == "round_robin":
            worker = WORKERS[rr_index % len(WORKERS)]
            rr_index += 1
        else:
            worker = min(WORKERS, key=lambda w: (counts[w], loads[w], w))

        units = int(job["compute_units"])
        counts[worker] += 1
        loads[worker] += units
        results.append((job["job_id"], worker, units))
        print(f"[ALLOCATE] Job {job['job_id']} ({units} units) -> {worker}")
        print(f"[LOAD] {worker}: {counts[worker]} job(s), {loads[worker]} compute units")

    print("\n[SUMMARY]")
    for worker in WORKERS:
        print(f"{worker}: {counts[worker]} job(s), {loads[worker]} compute units")
    return results

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "workload_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            jobs = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    print("=== DYNAMIC LOAD BALANCING SIMULATOR ===")
    print(f"[INPUT] Read {len(jobs)} job record(s) from {filename}")
    schedule(jobs, "round_robin")
    schedule(jobs, "least_connections")

if __name__ == "__main__":
    main()
