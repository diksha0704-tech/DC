# Dynamic Load Balancing — Theory, explanation and viva

## Aim
Distribute incoming CSV jobs among worker nodes using Round-Robin and/or Least-Connections scheduling.

## Theory (10 points)
1. Load balancing distributes work among multiple worker nodes.
2. Its purpose is to avoid overloading one worker.
3. A job may have a job ID and compute-unit requirement.
4. Round Robin assigns jobs sequentially to workers.
5. After the last worker, assignment returns to the first worker.
6. Least Connections selects the worker with the fewest assigned jobs.
7. A tie can be resolved using current compute load.
8. The scheduler updates worker load after each assignment.
9. A summary shows jobs and compute units assigned to each worker.
10. Balanced distribution can improve resource utilization and response time.

## Code explanation
The program reads pending, unassigned jobs from CSV. It runs two strategies for comparison. Round Robin uses a rotating index. Least Connections chooses the worker with the smallest job count, then the smallest accumulated compute units. It prints every assignment and final worker summaries. This is a local scheduling simulation.

## Expected output (illustrative)
```text
=== ROUND_ROBIN SCHEDULING ===
[ALLOCATE] Job J101 (35 units) -> Worker_1
[ALLOCATE] Job J102 (20 units) -> Worker_2
[ALLOCATE] Job J103 (50 units) -> Worker_3
...
=== LEAST_CONNECTIONS SCHEDULING ===
...
[SUMMARY]
Worker_1: ... job(s), ... compute units
```

## Viva
1. **What is load balancing?** Distributing work across multiple resources.
2. **Why is it needed?** To avoid overload and improve utilization.
3. **What is Round Robin?** Sequential assignment in a repeating worker order.
4. **What is Least Connections?** Assigning work to the worker with the fewest active/assigned jobs.
5. **What is a worker node?** A machine or process that handles assigned work.
6. **What is compute load?** The amount of work assigned, represented here by compute units.
7. **How are ties broken here?** By lower accumulated compute units, then worker name.
8. **What is a pending job?** A job waiting to be assigned.
9. **Can Round Robin consider job size?** Basic Round Robin does not; it rotates assignments.
10. **What does the summary show?** Number of jobs and total compute units per worker.
