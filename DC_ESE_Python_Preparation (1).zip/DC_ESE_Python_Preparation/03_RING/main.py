"""
RING LEADER ELECTION
CSV columns: node_id,next_node_id,is_active,priority_rank
Run: python main.py [csv_filename]
"""
import csv
import sys

def truth(value):
    return value.strip().lower() in ("true", "1", "yes", "active")

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "ring_nodes_sample.csv"
    nodes = {}
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                nid = int(r["node_id"])
                nodes[nid] = {
                    "next": int(r["next_node_id"]),
                    "active": truth(r["is_active"]),
                    "priority": int(r["priority_rank"])
                }
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    active = [nid for nid, n in nodes.items() if n["active"]]
    if not active:
        print("[ELECTION] No active nodes.")
        return

    print("[FAILURE] Coordinator failure detected.")
    start = min(active)
    current = start
    visited = set()
    token_ids = []
    print(f"[RING] Election token starts at Node {start}")

    while current not in visited and current in nodes:
        visited.add(current)
        if nodes[current]["active"]:
            token_ids.append(current)
            print(f"[TOKEN] Node {current} adds its ID to election token")
        nxt = nodes[current]["next"]
        # Follow the configured ring; skip inactive nodes by forwarding onward.
        hops = 0
        while nxt in nodes and not nodes[nxt]["active"] and hops < len(nodes):
            print(f"[RING] Node {nxt} is inactive; forwarding token")
            nxt = nodes[nxt]["next"]
            hops += 1
        if nxt not in nodes or nxt == start:
            break
        current = nxt

    # Include any active node not reached because of an incomplete/broken sample ring.
    for nid in sorted(active):
        if nid not in token_ids:
            token_ids.append(nid)
            print(f"[TOKEN] Node {nid} included in election token")

    leader = max(token_ids)
    print(f"[TOKEN] Completed token: {token_ids}")
    print(f"[COORDINATOR] Highest ID in token is Node {leader}")
    print(f"[RESULT] New leader elected: Node {leader}")

if __name__ == "__main__":
    main()
