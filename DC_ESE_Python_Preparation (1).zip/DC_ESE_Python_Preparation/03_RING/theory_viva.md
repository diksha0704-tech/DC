# Ring Algorithm — Theory, explanation and viva

## Aim
Implement the Ring Leader Election Algorithm to circulate an election token among active ring nodes and elect the node with the highest ID.

## Theory (10 points)
1. Processes are arranged in a logical ring.
2. Each process knows its next process in the ring.
3. A coordinator failure starts an election.
4. An active process creates an election message or token.
5. The token circulates from one active node to the next.
6. Each active node contributes its ID to the token.
7. Failed or inactive nodes are skipped.
8. The token returns after traversing the ring.
9. The highest ID in the token is selected as leader.
10. The new leader is announced to the group.

## Code explanation
The CSV defines each node's next node and active status. The program starts at an active node, follows `next_node_id`, skips inactive nodes and records active IDs. It then selects the maximum ID from the completed election token. A fallback includes active nodes if the supplied ring links are incomplete.

## Expected output (illustrative)
```text
[FAILURE] Coordinator failure detected.
[RING] Election token starts at Node 1
[TOKEN] Node 1 adds its ID to election token
[TOKEN] Node 2 adds its ID to election token
...
[RESULT] New leader elected: Node 5
```

## Viva
1. **What is Ring Election?** A leader-election method in which an election message circulates around a logical ring.
2. **What is a ring topology?** Each node has a logical successor.
3. **What does the token contain?** IDs of participating active nodes.
4. **How is the leader selected here?** The highest node ID in the token.
5. **What happens to a failed node?** It is skipped.
6. **What is `next_node_id`?** The ID of the node to which the current node forwards the token.
7. **When does election end?** When the token completes its circulation.
8. **Does every node need a direct connection to every other node?** No; it needs its successor link.
9. **What if the ring link is broken?** The implementation uses a fallback to include remaining active nodes.
10. **Ring vs Bully?** Ring circulates an election message; Bully sends election messages to higher-ID processes.
