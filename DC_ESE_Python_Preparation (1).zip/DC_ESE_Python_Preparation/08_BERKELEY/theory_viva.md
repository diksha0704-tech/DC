# Berkeley's Algorithm — Theory, explanation and viva

## Aim
Read node clock times from CSV, discard nodes marked faulty, calculate an average time and determine each valid node's adjustment.

## Theory (10 points)
1. Berkeley's algorithm synchronizes physical clocks in a distributed group.
2. A coordinator polls the clocks of participating nodes.
3. Each node reports its local clock time.
4. Faulty or outlier nodes can be excluded from the calculation.
5. The coordinator calculates an average of the accepted clock values.
6. It calculates the difference between the average and each node's time.
7. A positive offset means the node must advance its clock.
8. A negative offset means the node must delay its clock.
9. The coordinator distributes the adjustment values.
10. Nodes adjust their clocks to move toward a common group time.

## Code explanation
The CSV contains node ID, clock time and faulty status. The program prints every polled time, excludes rows marked TRUE, computes the average of remaining clocks, and prints the signed offset for each valid node. The chit does not specify a numerical outlier threshold, so this implementation uses the explicit `is_faulty` flag.

## Expected output (sample calculation)
Valid times: 3600, 3604, 3598, 3602
Average = 3601 seconds.
N1 adjustment = +1 sec; N2 = -3 sec; N3 = +3 sec; N5 = -1 sec.
N4 is discarded because it is marked faulty.

## Viva
1. **What is Berkeley's algorithm?** A group clock synchronization algorithm using a coordinator.
2. **What does the coordinator do?** Polls clocks, calculates an average and sends offsets.
3. **Does it need an external UTC server?** Not necessarily; it synchronizes nodes to a group time.
4. **Why calculate an average?** To obtain a common target time for participating nodes.
5. **What is clock offset?** Difference between target average time and a node's current time.
6. **What does positive offset mean?** The node's clock should advance.
7. **What does negative offset mean?** The node's clock should be delayed.
8. **Why discard faulty nodes?** Their values could distort the average.
9. **What does `is_faulty` represent here?** Whether the CSV row should be excluded.
10. **Cristian vs Berkeley?** Cristian uses a time server; Berkeley coordinates clocks among a group of nodes.
