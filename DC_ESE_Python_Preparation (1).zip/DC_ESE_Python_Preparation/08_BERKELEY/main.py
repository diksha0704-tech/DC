"""
BERKELEY CLOCK SYNCHRONIZATION
CSV columns: node_id,clock_time_sec,is_faulty
Rows marked TRUE in is_faulty are excluded from averaging.
Run: python main.py [csv_filename]
"""
import csv
import sys

def truth(value):
    return value.strip().lower() in ("true", "1", "yes")

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "node_clocks_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    valid = []
    print("=== BERKELEY CLOCK SYNCHRONIZATION ===")
    for r in rows:
        node = r["node_id"]
        clock = float(r["clock_time_sec"])
        faulty = truth(r["is_faulty"])
        print(f"[POLL] {node} clock={clock:g} sec | faulty={faulty}")
        if faulty:
            print(f"[DISCARD] {node} excluded as faulty/outlier")
        else:
            valid.append((node, clock))

    if not valid:
        print("[ERROR] No valid clocks available for averaging.")
        return

    average = sum(clock for _, clock in valid) / len(valid)
    print(f"\n[AVERAGE] Synchronized average time = {average:.2f} sec")
    print("[ADJUSTMENTS]")
    for node, clock in valid:
        offset = average - clock
        direction = "advance" if offset > 0 else "delay" if offset < 0 else "no change"
        print(f"{node}: current={clock:g} sec, offset={offset:+.2f} sec -> {direction}")

if __name__ == "__main__":
    main()
