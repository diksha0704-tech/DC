# Vector Clocks — Theory, explanation and viva

## Aim
Implement vector clocks [V1, V2, V3] to track events and determine causal relationships or concurrency.

## Theory (10 points)
1. A vector clock maintains one counter for each process.
2. For three processes, each timestamp has three components.
3. A process increments its own component for a local event.
4. A send event increments the sender's component and attaches the vector.
5. On receive, the process takes the component-wise maximum of its vector and the received vector.
6. The receiver then increments its own component.
7. Vector A is less than B if every component of A is less than or equal to B.
8. At least one component must be strictly smaller for strict causal precedence.
9. If neither vector is less than the other, the events are concurrent.
10. Vector clocks can distinguish concurrency in a way Lamport scalar clocks cannot.

## Code explanation
The program maintains vectors for P1, P2 and P3. SEND saves a copy of the sender vector in a message queue. RECEIVE merges the incoming vector component by component using maximum, then increments the receiver's own component. LOCAL increments only the process's own component. The program compares event snapshots to report causal precedence or concurrency.

## Expected output (illustrative)
```text
[SEND] E1 at P1 -> [1, 0, 0]
[RECEIVE] E2 at P2 -> [1, 1, 0]
[LOCAL] E3 at P2 -> [1, 2, 0]
[LOCAL] E4 at P3 -> [0, 0, 1]
...
E3 ... vs E4 ...: E3 || E4 (concurrent)
```

## Viva
1. **What is a vector clock?** A logical clock containing one counter per process.
2. **Why three values?** The chit specifies three processes P1, P2 and P3.
3. **What happens on a local event?** Increment that process's own component.
4. **What happens on send?** Increment own component and attach the vector.
5. **What happens on receive?** Merge component-wise maximum, then increment own component.
6. **When does A causally precede B?** If A≤B component-wise and A≠B.
7. **When are events concurrent?** Neither vector is strictly less than the other.
8. **Can Lamport clocks detect concurrency exactly?** No.
9. **What does `||` mean?** The events are concurrent.
10. **What is the cost of vector clocks?** Vector size grows with the number of processes.
