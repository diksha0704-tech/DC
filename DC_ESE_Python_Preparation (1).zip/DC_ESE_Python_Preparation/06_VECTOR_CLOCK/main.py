"""
VECTOR CLOCKS
CSV columns: event_id,process_id,event_action,target_process
Actions: SEND (target is receiver), RECEIVE (target is sender), LOCAL.
Run: python main.py [csv_filename]
"""
import csv
import sys
from collections import defaultdict, deque
from itertools import combinations

PROCESSES = ["P1", "P2", "P3"]

def leq(a, b):
    return all(x <= y for x, y in zip(a, b))

def strictly_less(a, b):
    return leq(a, b) and a != b

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "vector_events_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            events = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    clocks = {p: [0, 0, 0] for p in PROCESSES}
    messages = defaultdict(deque)
    event_vectors = []

    print("=== VECTOR CLOCKS [P1, P2, P3] ===")
    for e in events:
        eid = e["event_id"]
        pid = e["process_id"].strip()
        action = e["event_action"].strip().upper()
        target = e["target_process"].strip()
        if pid not in clocks:
            print(f"[SKIP] Unknown process {pid}; supported processes: {PROCESSES}")
            continue
        i = PROCESSES.index(pid)

        if action == "RECEIVE":
            key = (target, pid)  # sender, receiver
            incoming = messages[key].popleft() if messages[key] else [0, 0, 0]
            clocks[pid] = [max(x, y) for x, y in zip(clocks[pid], incoming)]
            clocks[pid][i] += 1
        else:
            clocks[pid][i] += 1
            if action == "SEND" and target in clocks:
                messages[(pid, target)].append(clocks[pid].copy())

        snapshot = clocks[pid].copy()
        event_vectors.append((eid, snapshot))
        print(f"[{action}] {eid} at {pid} -> {snapshot}")

    print("\n=== CAUSAL RELATION BETWEEN EVENTS ===")
    for (id1, v1), (id2, v2) in combinations(event_vectors, 2):
        if strictly_less(v1, v2):
            relation = f"{id1} causally precedes {id2}"
        elif strictly_less(v2, v1):
            relation = f"{id2} causally precedes {id1}"
        else:
            relation = f"{id1} || {id2} (concurrent)"
        print(f"{id1} {v1} vs {id2} {v2}: {relation}")

if __name__ == "__main__":
    main()
