# Lamport Logical Clock — Theory, explanation and viva

## Aim
Assign Lamport timestamps to events read from a CSV file and print their total causal order.

## Theory (10 points)
1. Distributed processes do not always share a perfectly synchronized physical clock.
2. Lamport clocks provide logical timestamps for events.
3. Each process maintains an integer logical clock.
4. Before a local or send event, the process increments its clock.
5. A send event carries the sender's timestamp.
6. On receiving a message, the receiver compares its clock with the message timestamp.
7. The receiver updates its clock using `L = max(L, T_msg) + 1`.
8. If event A causes event B, then timestamp(A) is less than timestamp(B).
9. Timestamps alone cannot prove that two events are concurrent.
10. A tie-break such as process ID can create a deterministic total display order.

## Code explanation
Each process has a clock in a dictionary. SEND events increment the local clock and save the timestamp in a message queue. RECEIVE rows identify the sender in `message_to`, retrieve the matching message timestamp, and apply the Lamport formula. Other event types are treated as local events. Finally, events are sorted by timestamp and process ID.

## Expected output (illustrative)
```text
[SEND] E1 at P1: clock = 1
[LOCAL] E2 at P1: clock = 2
[RECEIVE] E3 at P2: max(0, 1) + 1 = 2
...
=== TOTAL ORDER (timestamp, process ID) ===
```

## Viva
1. **What is a logical clock?** A counter used to order events logically.
2. **Why not use physical time?** Physical clocks on machines may differ.
3. **What is the Lamport rule for a local event?** Increment the process clock by one.
4. **What is the receive rule?** `L = max(L, T_msg) + 1`.
5. **What is a send event?** An event that sends a message with its timestamp.
6. **What is happened-before?** A relation describing causal order between events.
7. **Does A→B imply L(A)<L(B)?** Yes.
8. **Does L(A)<L(B) prove A caused B?** No.
9. **Why sort by process ID too?** To break equal-timestamp ties deterministically.
10. **What does `message_to` mean in this implementation?** Receiver for SEND; sender for RECEIVE.
