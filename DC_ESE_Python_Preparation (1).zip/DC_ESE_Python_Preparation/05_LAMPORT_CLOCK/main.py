"""
LAMPORT LOGICAL CLOCK
CSV columns: event_id,process_id,event_type,message_to,initial_clock
SEND: message_to is receiver process.
RECEIVE: message_to is sender process; matched with an earlier SEND.
Run: python main.py [csv_filename]
"""
import csv
import sys
from collections import defaultdict, deque

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "events_sample.csv"
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            events = list(csv.DictReader(f))
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found.")
        return

    clocks = defaultdict(int)
    sent = defaultdict(deque)
    stamped = []

    print("=== LAMPORT LOGICAL CLOCK ===")
    for e in events:
        eid = e["event_id"]
        pid = e["process_id"]
        kind = e["event_type"].strip().upper()
        peer = e["message_to"].strip()
        initial = int(e["initial_clock"] or 0)
        clocks[pid] = max(clocks[pid], initial)

        if kind == "RECEIVE":
            key = (peer, pid)  # sender, receiver
            msg_time = sent[key].popleft() if sent[key] else 0
            old = clocks[pid]
            clocks[pid] = max(clocks[pid], msg_time) + 1
            print(f"[RECEIVE] {eid} at {pid}: max({old}, {msg_time}) + 1 = {clocks[pid]}")
        else:
            clocks[pid] += 1
            print(f"[{kind}] {eid} at {pid}: clock = {clocks[pid]}")
            if kind == "SEND":
                sent[(pid, peer)].append(clocks[pid])

        stamped.append((clocks[pid], pid, eid))

    print("\n=== TOTAL ORDER (timestamp, process ID) ===")
    for timestamp, pid, eid in sorted(stamped):
        print(f"{eid} | Process={pid} | Lamport time={timestamp}")

if __name__ == "__main__":
    main()
