"""
RMI/RPC SIMULATION
Reads calls from CSV, marshals parameters, dispatches a server-side method,
and prints the returned result. This is a local simulation: no network/socket
connection is created, as the question chit requires terminal execution only.
Run: python main.py [csv_filename]
"""
import csv
import sys

def process_data(value):
    return value * 2

def add(value):
    # Demonstration method: add 100 to the supplied numeric parameter.
    return value + 100

def square(value):
    return value ** 2

METHODS = {
    "processData": process_data,
    "add": add,
    "square": square,
}

def main():
    filename = sys.argv[1] if len(sys.argv) > 1 else "rpc_calls_sample.csv"
    print("=== RPC/RMI CLIENT-SERVER DISPATCHER ===")
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                call_id = row["call_id"]
                client = row["client_name"]
                method = row["method_name"]
                raw_value = row["param_value"]
                timestamp = row["timestamp"]

                print(f"\n[CLIENT] {client} | Call ID: {call_id} | Time: {timestamp}")
                print(f"[MARSHAL] Packing argument: {raw_value}")
                print(f"[DISPATCH] Client invoking method -> {method}")

                if method not in METHODS:
                    print(f"[ERROR] Unknown remote method: {method}")
                    continue

                try:
                    argument = float(raw_value)
                    if argument.is_integer():
                        argument = int(argument)
                except ValueError:
                    argument = raw_value

                print(f"[SERVER EXECUTION] Processing parameter -> {argument}")
                result = METHODS[method](argument)
                print(f"[RETURN] Result printed to terminal -> {result}")
    except FileNotFoundError:
        print(f"[ERROR] CSV file '{filename}' not found. Create it in this folder.")

if __name__ == "__main__":
    main()
