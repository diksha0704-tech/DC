# RMI / RPC — Theory, explanation and viva

## Aim
Simulate an RPC/RMI client-server procedure dispatcher that reads method calls from a CSV file, marshals arguments, executes the remote function, and prints the returned result.

## Theory (10 points)
1. RPC means Remote Procedure Call; RMI means Remote Method Invocation.
2. They allow a client to request an operation from a server.
3. The client prepares a request containing a method name and arguments.
4. Marshalling converts arguments into a transferable representation.
5. A dispatcher receives the request and identifies the requested method.
6. The server executes the selected procedure.
7. The result is returned to the client.
8. Unmarshalling converts the returned data into a usable value.
9. This practical simulates these stages locally using CSV input.
10. It does not create a real network connection or socket.

## Code explanation
The `csv.DictReader` reads each call as a dictionary. `METHODS` is a dispatch table mapping method names to Python functions. The program converts numeric parameters, calls the selected function, and prints the result. Unknown methods are reported instead of crashing.

## Expected output (illustrative)
```text
=== RPC/RMI CLIENT-SERVER DISPATCHER ===
[CLIENT] Client_A | Call ID: 101 | Time: 10:00:01
[MARSHAL] Packing argument: 450
[DISPATCH] Client invoking method -> processData
[SERVER EXECUTION] Processing parameter -> 450
[RETURN] Result printed to terminal -> 900
```

## Viva
1. **What is RPC?** A mechanism to call a procedure on another machine as if it were local.
2. **What is RMI?** A mechanism to invoke methods on remote objects, commonly associated with Java.
3. **What is marshalling?** Converting arguments into a representation suitable for transmission.
4. **What is unmarshalling?** Reconstructing received data into usable values.
5. **What is a stub?** A client-side proxy that represents the remote service.
6. **What does the dispatcher do?** Selects the server function based on the requested method.
7. **Is this program doing real networking?** No, it simulates request dispatch locally as required by the chit.
8. **What happens for an unknown method?** The program prints an error and continues.
9. **Why use CSV?** It provides structured input records for client calls.
10. **RPC vs RMI?** RPC is procedure-oriented; RMI is object/method-oriented.
